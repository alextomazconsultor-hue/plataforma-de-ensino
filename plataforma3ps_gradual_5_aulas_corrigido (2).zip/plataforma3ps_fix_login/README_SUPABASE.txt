Plataforma Método 3Ps — Supabase configurado

Este pacote já está com:
- SUPABASE_URL configurada
- SUPABASE_ANON_KEY / chave publicável configurada
- progresso por e-mail usando as tabelas:
  - student_progress
  - student_state

Teste:
1. Abra index.html localmente ou publique.
2. Entre com um e-mail.
3. Marque uma aula como concluída.
4. Veja se aparece linha em student_progress no Supabase.
5. Entre em outro navegador com o mesmo e-mail e confirme o progresso.

Atenção:
Nunca coloque service_role key no navegador.
