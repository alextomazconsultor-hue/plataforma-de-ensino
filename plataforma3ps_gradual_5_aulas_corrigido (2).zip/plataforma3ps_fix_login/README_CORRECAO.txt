# Plataforma Método 3Ps — 5 aulas liberadas corrigida

Correção aplicada:
- Login aberto voltou a funcionar.
- E-mail qualquer + senha com 3 caracteres entra.
- Aulas com release_status = soon aparecem como Em breve.
- Aulas em breve não abrem.
- Primeiras 5 aulas ficam liberadas se release_status = available.
- Progresso continua no Supabase por e-mail.

Teste:
1. Extraia o ZIP.
2. Abra index.html.
3. Entre com teste@teste.com e senha 123.
4. Confira se entra na plataforma.
5. Confira se as aulas além das 5 primeiras aparecem como Em breve.
