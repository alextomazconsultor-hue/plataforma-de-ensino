-- Plataforma Método 3Ps — módulos e aulas via Supabase
-- Rode este SQL no Supabase SQL Editor.
-- Depois desta atualização de código, você troca links de vídeo direto na tabela lessons.

create table if not exists course_modules (
  id text primary key,
  title text not null,
  description text,
  order_index integer not null,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

create table if not exists lessons (
  id text primary key,
  module_id text references course_modules(id) on delete cascade,
  title text not null,
  description text,
  video_url text,
  order_index integer not null,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

alter table course_modules enable row level security;
alter table lessons enable row level security;

drop policy if exists "open read course_modules" on course_modules;
drop policy if exists "open read lessons" on lessons;

create policy "open read course_modules"
on course_modules
for select
to anon
using (true);

create policy "open read lessons"
on lessons
for select
to anon
using (true);

-- Dados iniciais

insert into course_modules (id, title, description, order_index, is_active) values
('m1', 'Boas-vindas ao Método 3Ps', 'Conheça a plataforma, entenda a metodologia e prepare sua mentalidade para o crescimento.', 1, true),
('m2', 'Posicionamento do Corretor Digital', 'Construa autoridade, presença digital e gere confiança antes mesmo de falar sobre imóveis.', 2, true),
('m3', 'Prospecção e Geração de Leads', 'Métodos comprovados para atrair, abordar e organizar novos contatos todos os dias.', 3, true),
('m4', 'Tráfego Pago para Corretores', 'Aprenda a usar anúncios pagos para atrair leads qualificados e aumentar suas vendas de imóveis.', 4, true),
('m5', 'Follow-up e Organização Comercial', 'Transforme leads esquecidos em vendas. A arte do follow-up consistente e inteligente.', 5, true),
('m6', 'Fechamento e Propostas', 'Conduza o cliente até o sim com segurança, clareza e propostas que convencem.', 6, true),
('m7', 'Lives e Bônus', 'Aulas bônus e lives gravadas com conteúdos exclusivos para turbinar seus resultados.', 7, true)
on conflict (id) do update set
  title = excluded.title,
  description = excluded.description,
  order_index = excluded.order_index,
  is_active = excluded.is_active;

insert into lessons (id, module_id, title, description, video_url, order_index, is_active) values
('m1l1', 'm1', 'Introdução à plataforma', 'Nesta aula você conhecerá a plataforma Método 3Ps e aprenderá a navegar por todos os módulos e recursos disponíveis.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m1l2', 'm1', 'Como usar o método', 'Entenda a estrutura dos 3Ps — Posicionamento, Prospecção e Performance — e como aplicar cada etapa na sua rotina.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m1l3', 'm1', 'Mentalidade do corretor digital', 'Os princípios que diferenciam corretores comuns de corretores que faturam com consistência no ambiente digital.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true),
('m2l1', 'm2', 'Como construir autoridade', 'Estratégias práticas para se tornar referência no mercado imobiliário da sua região usando as redes sociais.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m2l2', 'm2', 'Como se posicionar no Instagram', 'Perfil, bio, destaque de stories, feed e cadência de publicações — tudo que você precisa para dominar o Instagram.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m2l3', 'm2', 'Como gerar confiança antes da venda', 'A venda começa muito antes do primeiro contato. Aprenda a preparar o terreno para um fechamento natural.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true),
('m3l1', 'm3', 'Como abordar contatos', 'Scripts e abordagens que geram resposta. Saiba o que falar, como falar e quando falar com novos leads.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m3l2', 'm3', 'Como organizar sua base', 'Um sistema simples para nunca mais perder um lead. Classificação, anotações e rotina de acompanhamento.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m3l3', 'm3', 'Como gerar oportunidades todos os dias', 'A rotina do corretor digital: hábitos diários que mantêm o pipeline sempre cheio de boas oportunidades.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true),
('m4l1', 'm4', 'O que é tráfego pago no mercado imobiliário', 'Entenda o conceito, por que funciona para corretores e como diferenciar tráfego pago de orgânico.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m4l2', 'm4', 'Como criar uma oferta simples', 'Antes de anunciar, você precisa de uma oferta irresistível. Aprenda a montar a oferta certa para o público certo.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m4l3', 'm4', 'Como montar um anúncio básico', 'Passo a passo para criar seu primeiro anúncio no Meta Ads focado em captação de leads imobiliários.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true),
('m4l4', 'm4', 'Como atender leads no WhatsApp', 'O lead chegou — e agora? Scripts, tempos de resposta e as primeiras mensagens que convertem.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 4, true),
('m5l1', 'm5', 'Como não perder clientes', 'Os erros mais comuns que fazem corretores perderem vendas prontas — e como evitar cada um deles.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m5l2', 'm5', 'Como usar rotina de follow-up', 'Monte uma cadência de acompanhamento que funciona sem ser inconveniente. Timing, frequência e tom.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m5l3', 'm5', 'Como priorizar leads quentes', 'Identifique quais leads têm mais chance de fechar hoje e concentre sua energia onde o retorno é maior.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true),
('m6l1', 'm6', 'Como apresentar a oportunidade', 'A apresentação que cria desejo. Como mostrar o imóvel certo, para a pessoa certa, no momento certo.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m6l2', 'm6', 'Como conduzir objeções', 'Preço, localização, prazo — aprenda a responder as objeções mais comuns sem perder o controle da negociação.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m6l3', 'm6', 'Como criar proposta simples', 'Uma proposta clara vence uma complexa sempre. Modelo, estrutura e o que não pode faltar.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true),
('m7l1', 'm7', 'Aula bônus 1', 'Conteúdo exclusivo extra para complementar sua jornada no Método 3Ps.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1, true),
('m7l2', 'm7', 'Aula bônus 2', 'Mais um conteúdo especial preparado para os alunos mais dedicados da plataforma.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 2, true),
('m7l3', 'm7', 'Live gravada', 'Gravação da mentoria ao vivo com perguntas e respostas, estratégias avançadas e casos reais.', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 3, true)
on conflict (id) do update set
  module_id = excluded.module_id,
  title = excluded.title,
  description = excluded.description,
  video_url = excluded.video_url,
  order_index = excluded.order_index,
  is_active = excluded.is_active;


-- =============================================
-- LIBERAÇÃO GRADUAL DAS AULAS
-- =============================================
alter table lessons
add column if not exists release_status text default 'soon';

-- Primeiras 5 aulas liberadas.
update lessons
set release_status = 'available'
where id in ('m1l1', 'm1l2', 'm1l3', 'm2l1', 'm2l2');

-- Demais aulas aparecem como Em breve.
update lessons
set release_status = 'soon'
where id not in ('m1l1', 'm1l2', 'm1l3', 'm2l1', 'm2l2');

-- Renomear as 5 primeiras aulas da jornada inicial.
update lessons set title = 'Boas-vindas ao Método 3Ps',
description = 'Uma visão geral da plataforma, da comunidade e da jornada que você vai percorrer.'
where id = 'm1l1';

update lessons set title = 'Como usar a plataforma',
description = 'Aprenda como acessar os módulos, assistir aulas, acompanhar seu progresso e usar os materiais.'
where id = 'm1l2';

update lessons set title = 'A mentalidade do corretor digital',
description = 'Os princípios para sair do improviso e atuar com clareza, processo e consistência.'
where id = 'm1l3';

update lessons set title = 'Os 3 pilares: Posicionamento, Prospecção e Processo',
description = 'Entenda a base do Método 3Ps e como cada pilar se conecta à sua rotina comercial.'
where id = 'm2l1';

update lessons set title = 'Primeira missão: ajuste seu posicionamento',
description = 'Sua primeira ação prática dentro da comunidade para começar a construir autoridade.'
where id = 'm2l2';
