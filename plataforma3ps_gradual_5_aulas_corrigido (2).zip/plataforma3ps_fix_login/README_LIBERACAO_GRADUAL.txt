# Plataforma Método 3Ps — Liberação gradual

Esta versão usa:
- Supabase para progresso por e-mail
- Supabase para carregar módulos/aulas
- 5 aulas liberadas
- demais aulas como "Em breve"

## Passo obrigatório no Supabase

Rode o arquivo `supabase_aulas.sql` no SQL Editor.

Ele vai:
- criar/atualizar course_modules
- criar/atualizar lessons
- adicionar a coluna release_status
- deixar as primeiras 5 aulas como available
- deixar as demais como soon

## Como liberar uma aula depois

No Supabase > Table Editor > lessons:

- release_status = available  → aula liberada
- release_status = soon       → aparece como Em breve
- is_active = false           → oculta a aula

## Como trocar vídeo

Na tabela lessons, edite a coluna video_url.

Use formato embed:
https://www.youtube.com/embed/CODIGO_DO_VIDEO

## Primeiras 5 aulas liberadas

- m1l1 — Boas-vindas ao Método 3Ps
- m1l2 — Como usar a plataforma
- m1l3 — A mentalidade do corretor digital
- m2l1 — Os 3 pilares: Posicionamento, Prospecção e Processo
- m2l2 — Primeira missão: ajuste seu posicionamento
